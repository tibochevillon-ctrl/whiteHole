import os, tempfile, shutil, glob
from flask import Flask, request, send_file, jsonify, send_from_directory
import yt_dlp

app = Flask(__name__, static_folder="static")
MAX_MB = 300

@app.route("/")
def home():
    return send_from_directory("static", "index.html")

@app.route("/api/download")
def download():
    url = (request.args.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return jsonify(error="Lien invalide."), 400
    tmp = tempfile.mkdtemp()
    opts = {
        "outtmpl": os.path.join(tmp, "video.%(ext)s"),
        "format": "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/b",
        "merge_output_format": "mp4",
        "max_filesize": MAX_MB * 1024 * 1024,
        "noplaylist": True,
        "quiet": True,
    }
    try:
        with yt_dlp.YoutubeDL(opts) as ydl:
            ydl.download([url])
        files = glob.glob(os.path.join(tmp, "video.*"))
        if not files:
            raise RuntimeError("Aucun fichier récupéré.")
        resp = send_file(files[0], mimetype="video/mp4", as_attachment=True,
                         download_name="video.mp4")
        resp.call_on_close(lambda: shutil.rmtree(tmp, ignore_errors=True))
        return resp
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        return jsonify(error="Impossible de télécharger cette vidéo (lien privé, trop lourde ou site bloqué)."), 422

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", 8080)))
